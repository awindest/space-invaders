export interface Props {
  // Add a question mark to make it optional
  children?: import('svelte').Snippet; 
}

export interface CanvasContext {
	canvas: HTMLCanvasElement | null
	ctx: CanvasRenderingContext2D | null
	width: number   // logical (CSS) pixels, NOT bitmap pixels
	height: number
}

export interface PositionType {
    x: number;
    y: number;
}

export interface VelocityType {
    x: number;
    y: number;
}

export interface LevelConfig {
    speedMultiplier: number;
    fireRate: number;       // frames between invader shots (lower = more frequent)
    missileSpeed: number;   // invader missile velocity
    invaderPattern: number[]; // sprite row per grid row [top → bottom]
    colorPattern: string[];   // color per grid row
}

// export interface ScorePopup {
//     x: number;
//     y: number;
//     text: string;
//     opacity: number;
//     color: string;
// }

// export interface GlobalGameStateType {
//     canvasContext?: CanvasRenderingContext2D | null
//     canvasHeight?: number
//     canvasWidth?: number
//     gameState: string
//     wave: number
//     okToPlaySound: boolean
//     score: number
//     lives: number
//     level: number
//     highScore: number
// }

// export interface SplashScreenType {
//     canvasContext: CanvasRenderingContext2D
//     invadersLogo: HTMLImageElement
//     invadersSpriteSheet: HTMLImageElement
//     canvasWidth: number
//     canvasHeight: number
//     fontSize: number
//     drawSplashScreen: () => void
//     drawScoringScreen: () => number | NodeJS.Timeout
// }

// export interface PlayerType {
//     position: PositionType
//     velocity: VelocityType
//     rotation: number
//     opacity: number
//     width: number
//     height: number
//     update: () => void
//     shoot: (fireballs: FireballType[]) => void
// }
// export interface InvaderMissileType {
//     canvasContext: CanvasRenderingContext2D
//     invadersSpriteSheet: HTMLImageElement
//     frameX: number
//     position: PositionType
//     velocity: VelocityType
//     // height: number
//     // width: number
//     draw: () => void
//     update: (deltaTime: DOMHighResTimeStamp) => void

// }
// export type InvaderType = {
//     canvasContext: CanvasRenderingContext2D
//     invadersSpriteSheet: HTMLImageElement
//     spriteRow: number
//     position: PositionType
//     velocity: VelocityType
//     frameX: number
//     timer: number
//     fps: number
//     interval: number
//     width: number
//     height: number
//     color: string
//     points: number
//     update: (deltaTime: DOMHighResTimeStamp, { velocity }: { velocity: VelocityType }) => void
//     draw: () => void
//     shoot: (invaderMissile: InvaderMissileType[]) => void

// }

// export type InvaderGridType = {
//     canvasContext: CanvasRenderingContext2D
//     // canvasWidth: number
//     invadersSpriteSheet: HTMLImageElement
//     // invaderPattern: [number]
//     // position: PositionType
//     velocity: VelocityType
//     invaders: InvaderType[]
//     width: number
//     position: PositionType
//     update: () => void
// }

// export type ParticleType = {
// 		x: number
// 		y: number
// 		vx: number
// 		vy: number
//         radius: number
//         color: string
//         fades: boolean
//         life: number
//         maxLife: number
//         size: number
//         draw: () => void
//         update: () => void
// 	}

// export type FireballType = {
//     canvasContext: CanvasRenderingContext2D
//     canvasWidth: number
//     canvasHeight: number
//     position: PositionType
//     velocity: VelocityType
//     frameY: number
//     timer: number
//     fps: number
//     interval: number
//     // image: HTMLImageElement
//     update: (deltaTime: DOMHighResTimeStamp) => void
// }