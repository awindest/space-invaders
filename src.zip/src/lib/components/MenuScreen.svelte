<!-- src/lib/MenuScreen.svelte -->
<script lang="ts">
	import { getContext, onMount } from 'svelte'
	import spriteSheetSrc from '$images/InvadersSpriteSheetFig.png'
	import Logo from '$components/Logo.svelte'

	const canvasCtx = getContext<{
		canvas: HTMLCanvasElement | null
		ctx: CanvasRenderingContext2D | null
	}>('canvas')

	// Coordinates measured directly from the 256x256 sprite sheet (frame 1 of each type)
	const SPRITES = {
		green: { x: 7, y: 0, w: 34, h: 32, points: '30' },
		cyan: { x: 1, y: 39, w: 46, h: 33, points: '20' },
		magenta: { x: 5, y: 75, w: 38, h: 33, points: '10' },
		ship: { x: 0, y: 105, w: 64, h: 34 }
	}
	const SPRITE_SCALE = 1.4
	const REVEAL_INTERVAL_MS = 1000 // delay between each score row appearing
	const REVEAL_ROWS = [SPRITES.green, SPRITES.cyan, SPRITES.magenta]

	// Mystery ship + prompt appear together, once all score rows have shown.
	// GameCanvas reads this to know when the reveal sequence has finished
	// (e.g. to gate dismissal and show the Insert Coin button).
	export const SHIP_REVEAL_MS = (REVEAL_ROWS.length + 1) * REVEAL_INTERVAL_MS

	let logo: Logo

	let spriteSheet: HTMLImageElement
	let spriteSheetLoaded = $state(false)

	onMount(() => {
		// logo = new Image()
		// logo.onload = () => (logoLoaded = true)
		// logo.src = logoSrc

		spriteSheet = new Image()
		spriteSheet.onload = () => (spriteSheetLoaded = true)
		spriteSheet.src = spriteSheetSrc
	})

	export function draw(elapsed: number) {
		const ctx = canvasCtx.ctx
		const canvas = canvasCtx.canvas
		if (!ctx || !canvas) return
		const cx = canvasCtx.width / 2
		const cy = canvasCtx.height / 2

		const rowHeight = 64
		const rowStartY = cy + 40
		logo.draw()

		if (spriteSheetLoaded) {
			REVEAL_ROWS.forEach((sprite, i) => {
				if (elapsed < (i + 1) * REVEAL_INTERVAL_MS) return
				const y = rowStartY + i * rowHeight
				const dw = sprite.w * SPRITE_SCALE
				const dh = sprite.h * SPRITE_SCALE
				ctx.drawImage(
					spriteSheet,
					sprite.x,
					sprite.y,
					sprite.w,
					sprite.h,
					cx - 90 - dw / 2,
					y - dh / 2,
					dw,
					dh
				)
				ctx.fillStyle = '#f4ffbf'
				ctx.font = '18px "beefd", monospace'
				ctx.textAlign = 'left'
				ctx.fillText(`= ${sprite.points} PTS`, cx - 40, y + 5)
			})
		}

		if (elapsed >= SHIP_REVEAL_MS) {
			const y = rowStartY + REVEAL_ROWS.length * rowHeight
			if (spriteSheetLoaded) {
				const dw = SPRITES.ship.w * SPRITE_SCALE
				const dh = SPRITES.ship.h * SPRITE_SCALE
				ctx.drawImage(
					spriteSheet,
					SPRITES.ship.x,
					SPRITES.ship.y,
					SPRITES.ship.w,
					SPRITES.ship.h,
					cx - 90 - dw / 2,
					y - dh / 2,
					dw,
					dh
				)
			}
			ctx.fillStyle = '#f4ffbf'
			ctx.font = '18px "beefd", monospace'
			ctx.textAlign = 'left'
			ctx.fillText('= ??? PTS', cx - 40, y + 8)

			// Blink every second, same cadence as the classic arcade screen
			const blinkOn = Math.floor((elapsed - SHIP_REVEAL_MS) / 1000) % 2 === 0
			if (blinkOn) {
				ctx.fillStyle = '#ff0000'
				ctx.font = '20px "Beefd", monospace'
				ctx.textAlign = 'center'
				// ctx.fillText('PRESS SPACE BAR TO START', cx, cy + 320)
				ctx.fillText('PRESS SPACE BAR TO START', cx, Math.min(cy + 320, canvasCtx.height - 40))
			}
		}
	}
</script>

<Logo bind:this={logo} />
<!-- no markup — this component only exposes draw(elapsed), called imperatively from GameCanvas -->
